
export interface findPlace extends ScriptComponent {
    navigating: boolean;
}